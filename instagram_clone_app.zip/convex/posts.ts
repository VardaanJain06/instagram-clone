import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

export const createPost = mutation({
  args: {
    imageId: v.id("_storage"),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }
    
    return await ctx.db.insert("posts", {
      imageId: args.imageId,
      caption: args.caption,
      authorId: userId,
    });
  },
});

export const getAllPosts = query({
  args: {},
  handler: async (ctx) => {
    const posts = await ctx.db
      .query("posts")
      .order("desc")
      .collect();

    return await Promise.all(
      posts.map(async (post) => {
        const author = await ctx.db.get(post.authorId);
        const imageUrl = await ctx.storage.getUrl(post.imageId);
        
        // Get like count
        const likes = await ctx.db
          .query("likes")
          .withIndex("by_post", (q) => q.eq("postId", post._id))
          .collect();
        
        // Check if current user liked this post
        const userId = await getAuthUserId(ctx);
        const userLiked = userId ? likes.some(like => like.userId === userId) : false;
        
        return {
          ...post,
          author: author?.name || author?.email || "Unknown",
          imageUrl,
          likeCount: likes.length,
          userLiked,
        };
      })
    );
  },
});

export const getUserPosts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const posts = await ctx.db
      .query("posts")
      .filter((q) => q.eq(q.field("authorId"), userId))
      .order("desc")
      .collect();

    return await Promise.all(
      posts.map(async (post) => {
        const imageUrl = await ctx.storage.getUrl(post.imageId);
        
        // Get like count
        const likes = await ctx.db
          .query("likes")
          .withIndex("by_post", (q) => q.eq("postId", post._id))
          .collect();
        
        return {
          ...post,
          imageUrl,
          likeCount: likes.length,
        };
      })
    );
  },
});

export const deletePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const post = await ctx.db.get(args.postId);
    if (!post) {
      throw new Error("Post not found");
    }

    if (post.authorId !== userId) {
      throw new Error("Not authorized to delete this post");
    }

    // Delete all likes for this post
    const likes = await ctx.db
      .query("likes")
      .withIndex("by_post", (q) => q.eq("postId", args.postId))
      .collect();
    
    for (const like of likes) {
      await ctx.db.delete(like._id);
    }

    // Delete the post
    await ctx.db.delete(args.postId);
    
    // Delete the image from storage
    await ctx.storage.delete(post.imageId);
  },
});

export const toggleLike = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Check if user already liked this post
    const existingLike = await ctx.db
      .query("likes")
      .withIndex("by_user_and_post", (q) => 
        q.eq("userId", userId).eq("postId", args.postId)
      )
      .unique();

    if (existingLike) {
      // Unlike the post
      await ctx.db.delete(existingLike._id);
      return { liked: false };
    } else {
      // Like the post
      await ctx.db.insert("likes", {
        postId: args.postId,
        userId: userId,
      });
      return { liked: true };
    }
  },
});
